package com.erp.montfortuganda.common.importframework.excel;

import com.erp.montfortuganda.common.importframework.context.ImportContext;
import com.erp.montfortuganda.common.importframework.registry.ImportTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.springframework.stereotype.Component;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import javax.xml.parsers.SAXParserFactory;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

@Slf4j
@Component
public class GenericExcelReader {

    public void processFileInChunks(
            InputStream fileStream,
            ImportContext context,
            ImportTemplate template,
            Consumer<List<Map<String, String>>> chunkConsumer) throws Exception {

        try (OPCPackage pkg = OPCPackage.open(fileStream)) {
            XSSFReader xssfReader = new XSSFReader(pkg);
            StylesTable styles = xssfReader.getStylesTable();
            ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(pkg);

            XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
            if (iter.hasNext()) {
                try (InputStream sheetStream = iter.next()) {
                    processSheet(styles, strings, sheetStream, context.getChunkSize(), chunkConsumer, context.getTargetRowNumbers());
                }
            }
        }
    }

    private void processSheet(StylesTable styles, ReadOnlySharedStringsTable strings, InputStream sheetInputStream, int chunkSize, Consumer<List<Map<String, String>>> chunkConsumer, Set<Integer> targetRowNumbers) throws Exception {
        SAXParserFactory saxFactory = SAXParserFactory.newInstance();
        saxFactory.setNamespaceAware(true);
        XMLReader sheetParser = saxFactory.newSAXParser().getXMLReader();

        RowAccumulator handler = new RowAccumulator(chunkSize, chunkConsumer, targetRowNumbers);

        sheetParser.setContentHandler(new XSSFSheetXMLHandler(styles, null, strings, handler, new org.apache.poi.ss.usermodel.DataFormatter(), false));
        sheetParser.parse(new InputSource(sheetInputStream));

        handler.flush();
    }

    private static class RowAccumulator implements SheetContentsHandler {
        private final int chunkSize;
        private final Consumer<List<Map<String, String>>> chunkConsumer;
        private final Set<Integer> targetRowNumbers;

        private final List<Map<String, String>> currentChunk;
        private Map<String, String> currentRow;
        private final Map<Integer, String> headerMap;

        private boolean isHeaderRow = true;

        public RowAccumulator(int chunkSize, Consumer<List<Map<String, String>>> chunkConsumer, Set<Integer> targetRowNumbers) {
            this.chunkSize = chunkSize;
            this.chunkConsumer = chunkConsumer;
            this.targetRowNumbers = targetRowNumbers;
            this.currentChunk = new ArrayList<>(chunkSize);
            this.headerMap = new HashMap<>();
        }

        @Override
        public void startRow(int rowNum) {
            if (rowNum > 0) {
                isHeaderRow = false;
                int actualRowNum = rowNum + 1; // 1-indexed for business logic

                // FAST-FORWARD SKIP
                if (targetRowNumbers != null && !targetRowNumbers.contains(actualRowNum)) {
                    currentRow = null;
                    return;
                }
                currentRow = new HashMap<>();
            }
        }

        @Override
        public void endRow(int rowNum) {
            if (isHeaderRow || currentRow == null) return;

            if (!currentRow.isEmpty()) {
                currentChunk.add(currentRow);
            }

            if (currentChunk.size() >= chunkSize) {
                flush();
            }
        }

        @Override
        public void cell(String cellReference, String formattedValue, org.apache.poi.xssf.usermodel.XSSFComment comment) {
            if (currentRow == null && !isHeaderRow) return; // Skip ignored rows

            int columnIndex = getColumnIndex(cellReference);
            if (formattedValue != null) formattedValue = formattedValue.trim();

            if (isHeaderRow) {
                headerMap.put(columnIndex, formattedValue);
            } else {
                String headerName = headerMap.get(columnIndex);
                if (headerName != null) {
                    currentRow.put(headerName, formattedValue);
                }
            }
        }

        public void flush() {
            if (!currentChunk.isEmpty()) {
                chunkConsumer.accept(new ArrayList<>(currentChunk));
                currentChunk.clear();
            }
        }

        private int getColumnIndex(String cellReference) {
            String letters = cellReference.replaceAll("[0-9]", "");
            int sum = 0;
            for (int i = 0; i < letters.length(); i++) {
                sum *= 26;
                sum += (letters.charAt(i) - 'A' + 1);
            }
            return sum - 1;
        }
    }
}