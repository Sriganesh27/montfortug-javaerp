package com.erp.montfortuganda.common.importframework.engine;

import com.erp.montfortuganda.common.importframework.context.ImportContext;
import com.erp.montfortuganda.common.importframework.context.ImportSession;
import com.erp.montfortuganda.common.importframework.excel.GenericExcelReader;
import com.erp.montfortuganda.common.importframework.lifecycle.ImportStatus;
import com.erp.montfortuganda.common.importframework.metrics.ImportMetricsCollector;
import com.erp.montfortuganda.common.importframework.model.ErpImportError;
import com.erp.montfortuganda.common.importframework.plugin.ChunkProcessingResult;
import com.erp.montfortuganda.common.importframework.plugin.ImportPlugin;
import com.erp.montfortuganda.common.importframework.plugin.ValidationResult;
import com.erp.montfortuganda.common.importframework.registry.ImportTemplate;
import com.erp.montfortuganda.common.importframework.model.ErpImportErrorRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class EngineCoordinator {

    private final GenericExcelReader excelReader;
    private final ImportMetricsCollector metricsCollector;
    private final ErpImportErrorRepository errorRepository;

    public <DTO> void executeJob(ImportContext context, ImportSession session, ImportPlugin<DTO> plugin, Path filePath, ImportTemplate template) {
        log.info("EngineCoordinator starting job {} for module {}", context.getJobId(), plugin.getManifest().getModuleName());

        session.setCurrentLifecycle(ImportStatus.INITIALIZING);

        // PRE-FLIGHT VALIDATION HOOK
        if (plugin.getBeforeImportHook() != null) {
            try {
                // Fix: Call onBeforeImport instead of execute
                plugin.getBeforeImportHook().onBeforeImport(context);
            } catch (Exception e) {
                log.error("Job {} aborted during pre-flight validation: {}", context.getJobId(), e.getMessage());
                session.setCurrentLifecycle(ImportStatus.FAILED);
                throw new RuntimeException("Pre-flight validation failed: " + e.getMessage(), e);
            }
        }

        session.setCurrentLifecycle(ImportStatus.READING_ROWS);

        AtomicInteger globalRowCounter = new AtomicInteger(1);
        AtomicInteger totalSucceeded = new AtomicInteger(0);
        AtomicInteger totalValidationFailed = new AtomicInteger(0);
        AtomicInteger totalProcessingFailed = new AtomicInteger(0);

        try (InputStream is = Files.newInputStream(filePath)) {
            excelReader.processFileInChunks(is, context, template, rawChunk -> {

                session.setCurrentLifecycle(ImportStatus.VALIDATING_ROWS);
                List<DTO> validDtos = new ArrayList<>();
                int chunkValidationErrors = 0;

                for (Map<String, String> rowData : rawChunk) {
                    int currentRowNum = globalRowCounter.incrementAndGet();
                    DTO dto = plugin.getRowMapper().mapRow(rowData, currentRowNum);

                    // Note: Validator interface modified to accept Context for advanced validation
                    ValidationResult result = plugin.getValidator().validate(dto, currentRowNum, context);

                    if (result.isSuccess() && !result.isSkipRow()) {
                        validDtos.add(dto);
                    } else {
                        if (result.getErrors() != null && !result.getErrors().isEmpty()) {
                            chunkValidationErrors += 1;
                            List<ErpImportError> errors = result.getErrors().stream()
                                    .map(err -> ErpImportError.builder()
                                            .jobId(context.getJobId())
                                            .rowNumber(currentRowNum)
                                            .columnName(err.getColumnName())
                                            .cellValue(err.getCellValue())
                                            .errorCode(err.getErrorCode() != null ? err.getErrorCode() : "VALIDATION_ERROR")
                                            .severity("ERROR")
                                            .message(err.getMessage())
                                            .suggestedFix(err.getSuggestedFix())
                                            .build())
                                    .collect(Collectors.toList());
                            errorRepository.saveAll(errors);
                        } else {
                            chunkValidationErrors += 1;
                        }
                    }
                }

                session.setCurrentLifecycle(ImportStatus.SAVING_BATCH);

                ChunkProcessingResult chunkResult;
                try {
                    chunkResult = plugin.getProcessor().processChunk(validDtos, context);
                } catch (Exception e) {
                    log.error("FATAL ERROR processing chunk in job {}", context.getJobId(), e);
                    // Synthesize failure to keep engine alive
                    chunkResult = ChunkProcessingResult.builder()
                            .processed(validDtos.size())
                            .succeeded(0)
                            .validationFailed(0)
                            .processingFailed(validDtos.size())
                            .processingTimeMs(0)
                            .build();
                }

                // Accurate Metrics Merge
                totalSucceeded.addAndGet(chunkResult.getSucceeded());
                totalValidationFailed.addAndGet(chunkValidationErrors + chunkResult.getValidationFailed());
                totalProcessingFailed.addAndGet(chunkResult.getProcessingFailed());

                metricsCollector.recordChunkMetrics(context, chunkResult);

                session.setProcessedRows(globalRowCounter.get() - 1);
                session.setSuccessRows(totalSucceeded.get());
                session.setFailedRows(totalValidationFailed.get() + totalProcessingFailed.get());

            });

            session.setCurrentLifecycle((totalValidationFailed.get() + totalProcessingFailed.get()) > 0 ?
                    ImportStatus.COMPLETED_WITH_ERRORS : ImportStatus.COMPLETED);

            ChunkProcessingResult finalResult = ChunkProcessingResult.builder()
                    .processed(session.getProcessedRows())
                    .succeeded(session.getSuccessRows())
                    .validationFailed(totalValidationFailed.get())
                    .processingFailed(totalProcessingFailed.get())
                    .processingTimeMs(System.currentTimeMillis() - session.getStartTime())
                    .build();

            metricsCollector.recordFinalMetrics(context, finalResult);
            log.info("EngineCoordinator successfully completed job {}", context.getJobId());

        } catch (Exception e) {
            log.error("EngineCoordinator encountered a fatal system error for job {}", context.getJobId(), e);
            session.setCurrentLifecycle(ImportStatus.FAILED);
        }
    }
}