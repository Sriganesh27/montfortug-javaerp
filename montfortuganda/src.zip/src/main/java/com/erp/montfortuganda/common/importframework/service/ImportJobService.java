package com.erp.montfortuganda.common.importframework.service;

import com.erp.montfortuganda.common.importframework.model.ErpImportError;
import com.erp.montfortuganda.common.importframework.model.ErpImportJob;
import com.erp.montfortuganda.common.importframework.model.ErpImportErrorRepository;
import com.erp.montfortuganda.common.importframework.model.ErpImportJobRepository;
import com.erp.montfortuganda.common.importframework.report.ErrorExcelReportGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ImportJobService {

    private final ErpImportJobRepository jobRepository;
    private final ErpImportErrorRepository errorRepository;
    private final ErrorExcelReportGenerator reportGenerator;

    public Optional<ErpImportJob> getJobStatus(String jobId) {
        return jobRepository.findById(jobId);
    }

    public List<ErpImportJob> getRecentJobs(String moduleName) {
        // Find recent jobs, can be optimized with actual query
        return jobRepository.findAll(); 
    }

    public byte[] generateErrorReport(String jobId) {
        List<ErpImportError> errors = errorRepository.findByJobId(jobId);
        if (errors.isEmpty()) {
            return null;
        }
        return reportGenerator.generate(errors);
    }
}
