package com.erp.montfortuganda.common.importframework.model;

import com.erp.montfortuganda.common.importframework.lifecycle.ImportMode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ErpImportJobRepository extends JpaRepository<ErpImportJob, String> {

    // Fix: Ensure this exact signature is present to resolve the idempotency query
    Optional<ErpImportJob> findFirstByFileHashAndModuleAndBranchIdAndImportMode(
            String fileHash, String module, String branchId, ImportMode importMode);
}