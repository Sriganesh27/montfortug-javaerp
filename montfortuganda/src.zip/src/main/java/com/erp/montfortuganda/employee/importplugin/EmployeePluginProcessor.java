package com.erp.montfortuganda.employee.importplugin;

import com.erp.montfortuganda.common.importframework.context.ImportContext;
import com.erp.montfortuganda.common.importframework.plugin.ChunkProcessingResult;
import com.erp.montfortuganda.common.importframework.plugin.PluginProcessor;
import com.erp.montfortuganda.employee.entity.ErpEmployee;
import com.erp.montfortuganda.employee.enums.*;
import com.erp.montfortuganda.employee.repository.EmployeeRepository;
import com.erp.montfortuganda.school.repository.BranchRepository;
import com.erp.montfortuganda.school.Branch;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmployeePluginProcessor implements PluginProcessor<EmployeeImportDTO> {

    private final EmployeeRepository employeeRepository;
    private final BranchRepository branchRepository;
    private final TransactionTemplate transactionTemplate; // For programmatic row isolation

    @Override
    // REMOVED @Transactional to prevent chunk-wide tainting
    public ChunkProcessingResult processChunk(List<EmployeeImportDTO> validDtos, ImportContext context) {

        int succeeded = 0;
        int failed = 0;
        long start = System.currentTimeMillis();

        Branch branch = null;
        if (context.getBranchId() != null) {
            try {
                Optional<Branch> branchOpt = branchRepository.findById(Integer.valueOf(context.getBranchId()));
                if (branchOpt.isPresent()) {
                    branch = branchOpt.get();
                } else {
                    log.error("Branch with ID {} not found. All rows in this chunk will fail.", context.getBranchId());
                }
            } catch (NumberFormatException e) {
                log.error("Invalid branchId format: {}", context.getBranchId());
            }
        }

        final Branch finalBranch = branch; // Effectively final for lambda

        for (EmployeeImportDTO dto : validDtos) {
            if (finalBranch == null) {
                log.error("Skipping employee {} {} - branch not found", dto.getFirstName(), dto.getLastName());
                failed++;
                continue;
            }

            // ISOLATED TRANSACTION PER ROW
            Boolean result = transactionTemplate.execute(status -> {
                try {
                    ErpEmployee employee = new ErpEmployee();
                    employee.setEmployeeNo("EMP-" + java.util.UUID.randomUUID().toString().substring(0, 8).toUpperCase());
                    employee.setBranch(finalBranch);

                    employee.setFirstName(dto.getFirstName());
                    employee.setMiddleName(dto.getMiddleName());
                    employee.setLastName(dto.getLastName());
                    employee.setTitle(dto.getTitle());

                    StringBuilder fullName = new StringBuilder();
                    if (dto.getFirstName() != null) fullName.append(dto.getFirstName()).append(" ");
                    if (dto.getMiddleName() != null && !dto.getMiddleName().isBlank()) fullName.append(dto.getMiddleName()).append(" ");
                    if (dto.getLastName() != null) fullName.append(dto.getLastName());
                    employee.setFullName(fullName.toString().trim());

                    if (dto.getGender() != null && !dto.getGender().isBlank()) {
                        try { employee.setGender(Gender.valueOf(dto.getGender().trim().toUpperCase())); }
                        catch (IllegalArgumentException ignored) {}
                    }

                    employee.setOfficialEmail(dto.getOfficialEmail());
                    employee.setPersonalEmail(dto.getPersonalEmail());
                    employee.setMobileNo(dto.getMobileNumber());
                    employee.setAlternateMobile(dto.getAlternateMobile());
                    employee.setNationality(dto.getNationality());
                    employee.setNationalId(dto.getNationalId());

                    employee.setAddressDistrict(dto.getDistrict());
                    employee.setAddressCounty(dto.getCounty());
                    employee.setAddressSubCounty(dto.getSubCounty());
                    employee.setAddressParish(dto.getParish());
                    employee.setAddressVillage(dto.getVillage());
                    employee.setAddressStreet(dto.getStreet());
                    employee.setPostalCode(dto.getPostalCode());

                    EmployeeType empType = EmployeeType.PERMANENT;
                    if (dto.getEmployeeType() != null && !dto.getEmployeeType().isBlank()) {
                        try { empType = EmployeeType.valueOf(dto.getEmployeeType().trim().toUpperCase().replace(" ", "_")); }
                        catch (IllegalArgumentException ignored) {}
                    }
                    employee.setEmployeeType(empType);

                    if (dto.getEmploymentMode() != null && !dto.getEmploymentMode().isBlank()) {
                        try { employee.setEmploymentMode(EmploymentMode.valueOf(dto.getEmploymentMode().trim().toUpperCase().replace(" ", "_"))); }
                        catch (IllegalArgumentException ignored) {}
                    }

                    if (dto.getEmployeeCategory() != null && !dto.getEmployeeCategory().isBlank()) {
                        try { employee.setEmployeeCategory(EmployeeCategory.valueOf(dto.getEmployeeCategory().trim().toUpperCase().replace(" ", "_"))); }
                        catch (IllegalArgumentException ignored) {}
                    }

                    employee.setEmploymentStatus(EmploymentStatus.ACTIVE);

                    // Uses robust parsing
                    employee.setDateOfBirth(parseDate(dto.getDateOfBirth()));
                    employee.setJoiningDate(parseDate(dto.getJoiningDate()));

                    String loginVal = dto.getLoginEnabled();
                    employee.setLoginEnabled(loginVal != null && (loginVal.equalsIgnoreCase("yes") || loginVal.equalsIgnoreCase("true")));
                    employee.setEmployeeRemarks(dto.getRemarks());
                    employee.setActive(true);

                    employeeRepository.save(employee);
                    return true;
                } catch (Exception e) {
                    status.setRollbackOnly(); // Prevents Tainting the entire chunk
                    log.error("Failed to persist employee '{}' '{}': {}", dto.getFirstName(), dto.getLastName(), e.getMessage());
                    return false;
                }
            });

            if (Boolean.TRUE.equals(result)) succeeded++;
            else failed++;
        }

        return ChunkProcessingResult.builder()
                .processed(validDtos.size())
                .succeeded(succeeded)
                .validationFailed(0) // These passed validation
                .processingFailed(failed)
                .processingTimeMs(System.currentTimeMillis() - start)
                .build();
    }

    private LocalDate parseDate(String dateStr) {
        if (dateStr == null || dateStr.isBlank()) return null;
        String cleanStr = dateStr.trim();

        // ROBUST: Handle Excel numeric serial dates (e.g., 45000)
        if (cleanStr.matches("\\d+(\\.\\d+)?")) {
            try {
                double serial = Double.parseDouble(cleanStr);
                return LocalDate.of(1899, 12, 30).plusDays((long) serial);
            } catch (NumberFormatException ignored) {}
        }

        // Handle Standard Formats Fallback
        String[] formats = { "yyyy-MM-dd", "MM/dd/yyyy", "dd/MM/yyyy", "dd-MMM-yyyy", "dd-MM-yyyy" };
        for (String format : formats) {
            try {
                return LocalDate.parse(cleanStr, DateTimeFormatter.ofPattern(format));
            } catch (DateTimeParseException ignored) {}
        }

        log.warn("Could not parse date '{}' with known formats.", cleanStr);
        return null;
    }
}