package com.erp.montfortuganda.common.importframework.controller;

import com.erp.montfortuganda.common.importframework.engine.ImportFacade;
import com.erp.montfortuganda.common.importframework.lifecycle.ImportMode;
import com.erp.montfortuganda.common.importframework.model.ErpImportJob;
import com.erp.montfortuganda.common.importframework.service.ImportJobService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/import")
@RequiredArgsConstructor
public class ImportController {

    private final ImportFacade importFacade;
    private final ImportJobService importJobService;

    @PostMapping("/{moduleName}")
    public ResponseEntity<String> startImport(
            @PathVariable String moduleName,
            @RequestParam("file") MultipartFile file,
            @RequestParam(defaultValue = "INSERT") ImportMode mode,
            @RequestParam Integer branchId,
            @RequestParam Long userId) {

        try {
            // FIX: Use a stable, collision-free naming convention
            String originalName = file.getOriginalFilename() != null ?
                    file.getOriginalFilename().replaceAll("[^a-zA-Z0-9.-]", "_") : "import.xlsx";
            String uniqueFileName = java.util.UUID.randomUUID().toString() + "_" + originalName;

            java.nio.file.Path tempPath = java.nio.file.Path.of(System.getProperty("java.io.tmpdir"), uniqueFileName);
            file.transferTo(tempPath.toFile());

            String jobId = importFacade.submitImportJob(
                    moduleName,
                    String.valueOf(branchId),
                    String.valueOf(userId),
                    mode,
                    "hash-" + System.currentTimeMillis(),
                    uniqueFileName); // Pass the exact name that was saved to disk

            return ResponseEntity.accepted().body(jobId);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @GetMapping("/progress/{jobId}")
    public ResponseEntity<ErpImportJob> getProgress(@PathVariable String jobId) {
        return importJobService.getJobStatus(jobId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/history/{moduleName}")
    public ResponseEntity<List<ErpImportJob>> getHistory(@PathVariable String moduleName) {
        return ResponseEntity.ok(importJobService.getRecentJobs(moduleName));
    }

    @GetMapping("/errors/{jobId}")
    public ResponseEntity<byte[]> downloadErrorReport(@PathVariable String jobId) {
        byte[] excelData = importJobService.generateErrorReport(jobId);
        if (excelData == null) {
            return ResponseEntity.notFound().build();
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDispositionFormData("attachment", "Error_Report_" + jobId + ".xlsx");

        return ResponseEntity.ok()
                .headers(headers)
                .body(excelData);
    }
}
