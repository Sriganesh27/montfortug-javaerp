package com.erp.montfortuganda.common.importframework.report;

import com.erp.montfortuganda.common.importframework.model.ErpImportError;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.List;

@Component
public class ErrorExcelReportGenerator {

    /**
     * Uses SXSSFWorkbook to write out errors in a streaming fashion.
     * Crucial for protecting memory if there are 100k errors.
     */
    public byte[] generate(List<ErpImportError> errors) {
        try (SXSSFWorkbook workbook = new SXSSFWorkbook(100)) { // retain 100 rows in memory, flush others to disk
            Sheet sheet = workbook.createSheet("Import Errors");

            // Header
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Row Number");
            headerRow.createCell(1).setCellValue("Error Code");
            headerRow.createCell(2).setCellValue("Error Message");
            headerRow.createCell(3).setCellValue("Raw Data");

            // Data
            int rowIdx = 1;
            for (ErpImportError error : errors) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(error.getRowNumber());
                row.createCell(1).setCellValue(error.getErrorCode() != null ? error.getErrorCode() : "");
                row.createCell(2).setCellValue(error.getMessage() != null ? error.getMessage() : "");
                row.createCell(3).setCellValue(error.getCellValue() != null ? error.getCellValue() : "");
            }

            try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                workbook.write(bos);
                workbook.dispose(); // clean up temporary files
                return bos.toByteArray();
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate error report excel", e);
        }
    }
}
