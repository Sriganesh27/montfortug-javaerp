package com.erp.montfortuganda.common.importframework.plugin;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ChunkProcessingResult {
    private final int processed;
    private final int succeeded;
    private final int validationFailed; // Split for accuracy
    private final int processingFailed; // Split for accuracy
    private final long processingTimeMs;
}