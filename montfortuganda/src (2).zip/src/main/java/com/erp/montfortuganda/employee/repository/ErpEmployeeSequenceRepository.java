package com.erp.montfortuganda.employee.repository;

import com.erp.montfortuganda.employee.entity.ErpEmployeeSequence;
import com.erp.montfortuganda.employee.enums.EmployeeCategory;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Persistence operations for branch/category/year Employee-number sequences.

 * Employee-number generation must call findForUpdate(...) inside a database
 * transaction. The pessimistic write lock prevents two simultaneous Employee
 * registrations from receiving the same sequence number.
 */
@Repository
public interface ErpEmployeeSequenceRepository
        extends JpaRepository<ErpEmployeeSequence, Long> {

    Optional<ErpEmployeeSequence>
    findByBranch_BranchIdAndEmployeeCategoryAndSequenceYear(
            Integer branchId,
            EmployeeCategory employeeCategory,
            Integer sequenceYear
    );

    boolean existsByBranch_BranchIdAndEmployeeCategoryAndSequenceYear(
            Integer branchId,
            EmployeeCategory employeeCategory,
            Integer sequenceYear
    );

    /**
     * Locks an existing sequence row until the surrounding transaction
     * commits or rolls back.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
            select sequence
            from ErpEmployeeSequence sequence
            where sequence.branch.branchId = :branchId
              and sequence.employeeCategory = :employeeCategory
              and sequence.sequenceYear = :sequenceYear
            """)
    Optional<ErpEmployeeSequence> findForUpdate(
            @Param("branchId")
            Integer branchId,

            @Param("employeeCategory")
            EmployeeCategory employeeCategory,

            @Param("sequenceYear")
            Integer sequenceYear
    );
}