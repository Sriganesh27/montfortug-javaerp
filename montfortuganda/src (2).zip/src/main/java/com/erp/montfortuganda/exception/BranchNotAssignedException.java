package com.erp.montfortuganda.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class BranchNotAssignedException extends RuntimeException {
    public BranchNotAssignedException(String message) {
        super(message);
    }
}