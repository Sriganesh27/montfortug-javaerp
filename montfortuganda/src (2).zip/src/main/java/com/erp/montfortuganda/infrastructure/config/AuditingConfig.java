package com.erp.montfortuganda.infrastructure.config;

import com.erp.montfortuganda.auth.service.CurrentUserContext;
import com.erp.montfortuganda.auth.service.CurrentUserService;
import com.erp.montfortuganda.employee.service.support.EmployeeAuditContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

@Configuration
@EnableJpaAuditing(auditorAwareRef = "auditorProvider")
public class AuditingConfig {

    private final CurrentUserService currentUserService;

    public AuditingConfig(CurrentUserService currentUserService) {
        this.currentUserService = currentUserService;
    }

    @Bean
    public AuditorAware<String> auditorProvider() {
        return () -> {
            Optional<String> employeeActor =
                    EmployeeAuditContext.getCurrentActorId();

            if (employeeActor.isPresent()) {
                return employeeActor;
            }

            Authentication auth =
                    SecurityContextHolder
                            .getContext()
                            .getAuthentication();

            if (auth == null
                    || !auth.isAuthenticated()
                    || "anonymousUser".equals(auth.getPrincipal())) {

                return Optional.empty();
            }

            try {
                CurrentUserContext currentUser =
                        currentUserService.getCurrentUserContext(auth);

                if (currentUser != null
                        && currentUser.getUserId() != null) {

                    return Optional.of(
                            String.valueOf(currentUser.getUserId())
                    );
                }

                return Optional.of("system");

            } catch (Exception ignored) {
                return Optional.empty();
            }
        };
    }
}