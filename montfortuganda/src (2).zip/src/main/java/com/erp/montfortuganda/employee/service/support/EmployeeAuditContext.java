package com.erp.montfortuganda.employee.service.support;

import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.Optional;

/**
 * Holds the authenticated user ID only for the current employee transaction.
 *
 * Employee auditing can read this value without querying erp_users while
 * Hibernate is flushing employee records.
 */
public final class EmployeeAuditContext {

    private static final ThreadLocal<String> ACTOR_ID =
            new ThreadLocal<>();

    private EmployeeAuditContext() {
    }

    public static Optional<String> getCurrentActorId() {
        String actorId = ACTOR_ID.get();

        if (actorId == null || actorId.isBlank()) {
            return Optional.empty();
        }

        return Optional.of(actorId);
    }

    public static void bindUntilTransactionCompletion(
            Integer userId
    ) {
        if (userId == null || userId <= 0) {
            throw new IllegalArgumentException(
                    "A valid authenticated user ID is required."
            );
        }

        if (!TransactionSynchronizationManager
                .isActualTransactionActive()) {

            throw new IllegalStateException(
                    "Employee audit context requires an active transaction."
            );
        }

        if (!TransactionSynchronizationManager
                .isSynchronizationActive()) {

            throw new IllegalStateException(
                    "Transaction synchronization is not active."
            );
        }

        String actorId = String.valueOf(userId);
        String existingActorId = ACTOR_ID.get();

        if (existingActorId != null) {
            if (!existingActorId.equals(actorId)) {
                throw new IllegalStateException(
                        "A different employee audit user is already bound."
                );
            }

            return;
        }

        ACTOR_ID.set(actorId);

        TransactionSynchronizationManager.registerSynchronization(
                new TransactionSynchronization() {
                    @Override
                    public void afterCompletion(int status) {
                        ACTOR_ID.remove();
                    }
                }
        );
    }

    public static void clear() {
        ACTOR_ID.remove();
    }
}