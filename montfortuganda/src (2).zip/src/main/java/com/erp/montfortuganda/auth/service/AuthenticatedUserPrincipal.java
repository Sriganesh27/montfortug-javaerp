package com.erp.montfortuganda.auth.service;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.io.Serial;
import java.util.Collection;

/**
 * Spring Security principal containing the authenticated ERP user ID.
 *
 * Keeping the user ID inside the principal allows JPA auditing to obtain
 * created_by and updated_by without performing a database query during flush.
 */
public final class AuthenticatedUserPrincipal extends User {

    @Serial
    private static final long serialVersionUID = 1L;

    private final Integer userId;

    public AuthenticatedUserPrincipal(
            Integer userId,
            String username,
            String password,
            boolean enabled,
            Collection<? extends GrantedAuthority> authorities
    ) {
        super(
                username,
                password,
                enabled,
                true,
                true,
                true,
                authorities
        );

        if (userId == null) {
            throw new IllegalArgumentException(
                    "Authenticated user ID cannot be null."
            );
        }

        this.userId = userId;
    }

    public Integer getUserId() {
        return userId;
    }
}